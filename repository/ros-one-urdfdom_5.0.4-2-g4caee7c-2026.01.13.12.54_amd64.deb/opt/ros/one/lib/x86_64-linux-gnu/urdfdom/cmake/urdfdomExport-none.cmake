#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "urdfdom::urdfdom_model" for configuration "None"
set_property(TARGET urdfdom::urdfdom_model APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(urdfdom::urdfdom_model PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_NONE "console_bridge::console_bridge;tinyxml2::tinyxml2"
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/liburdfdom_model.so.5.0"
  IMPORTED_SONAME_NONE "liburdfdom_model.so.5.0"
  )

list(APPEND _cmake_import_check_targets urdfdom::urdfdom_model )
list(APPEND _cmake_import_check_files_for_urdfdom::urdfdom_model "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/liburdfdom_model.so.5.0" )

# Import target "urdfdom::urdfdom_world" for configuration "None"
set_property(TARGET urdfdom::urdfdom_world APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(urdfdom::urdfdom_world PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_NONE "console_bridge::console_bridge;tinyxml2::tinyxml2"
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/liburdfdom_world.so.5.0"
  IMPORTED_SONAME_NONE "liburdfdom_world.so.5.0"
  )

list(APPEND _cmake_import_check_targets urdfdom::urdfdom_world )
list(APPEND _cmake_import_check_files_for_urdfdom::urdfdom_world "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/liburdfdom_world.so.5.0" )

# Import target "urdfdom::urdfdom_sensor" for configuration "None"
set_property(TARGET urdfdom::urdfdom_sensor APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(urdfdom::urdfdom_sensor PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_NONE "console_bridge::console_bridge;tinyxml2::tinyxml2"
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/liburdfdom_sensor.so.5.0"
  IMPORTED_SONAME_NONE "liburdfdom_sensor.so.5.0"
  )

list(APPEND _cmake_import_check_targets urdfdom::urdfdom_sensor )
list(APPEND _cmake_import_check_files_for_urdfdom::urdfdom_sensor "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/liburdfdom_sensor.so.5.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
